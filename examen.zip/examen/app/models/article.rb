class Article < ApplicationRecord
	belongs_to :user
	validates :title, presence: true, uniqueness: true
	validates :author, presence: true
	validates :edit, presence: true
	validates :pages, presence: true
end
